package com.example.demo.entities;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.Data;

@Entity
@Data
public class Team {
    @Id
    private String teamId;
    private String value1;
    private String value2;


    @OneToMany(mappedBy = "team",fetch = FetchType.EAGER) 
    @JsonManagedReference
    private List<Member> members = new ArrayList<Member>();
}
