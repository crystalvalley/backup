package com.example.demo.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Member;
import com.example.demo.entities.Team;
import com.example.demo.repositories.MemberRepo;
import com.example.demo.repositories.TeamRepo;


@RestController
public class TestController {

    @Autowired
    TeamRepo repo;
    @Autowired
    MemberRepo mRepo;

    @GetMapping("/get")
    public List<Team> get(){
        List<Team> tList = repo.findAll();
        return tList;
    }    

    @PostMapping("/post")
    public Team post(@RequestBody Team team){
        System.out.println(team);
        //基本saveメソッドでinsert,update全部可能
        repo.save(team);
        return team;
    }
    @PostMapping("/post2")
    public Member post2(@RequestBody Member member){
        System.out.println(member);
        
        Team t = repo.findById(member.getTeamId()).get();
        member.setTeam(t);
        mRepo.save(member);
        return member;
    }
    @PostMapping("/save")
    @Transactional
    public Team save(@RequestBody Team team){
        //insertチェックしたい場合
        if(repo.existsById(team.getTeamId())){
            //insert
        }
        repo.save(team);
        return team;
    }
}
